package view;

import javafx.print.PageLayout;
import javafx.scene.layout.Border;
import javafx.scene.shape.Circle;

import javax.sound.midi.MidiDevice.Info;
import javax.swing.*;
import javax.swing.border.TitledBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.util.ArrayList;

public class GUIView extends JFrame implements ActionListener {

	private JPanel world;
	private JTextArea info;
	private JTextArea strukDis;
	private JTextArea activDis;
	private Button start;
	private Button exit;
	private JPanel units;
	private JPanel availableUnits;
	private JPanel respondingUnits;
	private JPanel treatingUnits;
	private JPanel p = new JPanel();
	public JPanel getP() {
		return p;
	}

	public JPanel getController() {
		return controller;
	}

	private JPanel controller;
	


	public GUIView() {
		/*Start page*/
		start= new Button("Start");
		start.setActionCommand("Start");
		exit=new Button("Exit");
		exit.setActionCommand("Exit");
		JPanel q=new JPanel();
		q.setLayout(new GridLayout(2, 3));
		q.setPreferredSize(new Dimension(300, 200));

		exit.setPreferredSize(new Dimension(200, 100));
		start.setPreferredSize(new Dimension(200, 100));
		q.add(start);
		q.add(exit);
		JPanel m= new  JPanel();
		 JTextArea t= new JTextArea("");
		t.setPreferredSize(new Dimension(500,500));
		m.add(t);
	
		m.setPreferredSize(new Dimension(600, 600));
		this.add(m,BorderLayout.EAST);
		this.add(m,BorderLayout.WEST);
		this.add(m,BorderLayout.NORTH);
		this.add(m,BorderLayout.SOUTH);
		this.add(q,BorderLayout.CENTER);
		this.setVisible(true);
		/*********/
		this.setBackground(Color.BLACK);
		
		controller = new JPanel();
		controller.setPreferredSize(new Dimension(200, 100));
		controller.setBorder(new TitledBorder("Cycle Controller"));
		
		this.add(controller, BorderLayout.SOUTH);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("RescueToWin");
		this.setSize((int) (Toolkit.getDefaultToolkit().getScreenSize().getWidth()),
				(int) (Toolkit.getDefaultToolkit().getScreenSize().getHeight()));
		this.setMaximizedBounds(new Rectangle(50, 50, 800, 800));
	
		
		
		
	
		p.setLayout(new GridLayout(4, 1));
		info = new JTextArea();
		JScrollPane s= new JScrollPane(info);
		
		s.setPreferredSize(new Dimension(120, 1000));
		s.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		s.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		info.setPreferredSize(new Dimension(1000, 1000));
		info.setEditable(false);
		info.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		String title = "INFO:";
		TitledBorder border = BorderFactory.createTitledBorder(title);
		info.setBorder(border);
		p.add(s);
		strukDis = new JTextArea();
		strukDis.setPreferredSize(new Dimension(200, 200));
		strukDis.setEditable(false);
		strukDis.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		String title2 = "Struck Disasters : ";
		TitledBorder border2 = BorderFactory.createTitledBorder(title2);
		strukDis.setBorder(border2);
		p.add(strukDis);
		/************/
		activDis = new JTextArea();
		activDis.setPreferredSize(new Dimension(200, 200));
		activDis.setEditable(false);
		activDis.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		String title3 = "Active Disasters : ";
		TitledBorder border3 = BorderFactory.createTitledBorder(title3);
		activDis.setBorder(border3);
		p.add(activDis);
		/**************/
		this.add(p, BorderLayout.WEST);
		units = new JPanel();
		units.setPreferredSize(new Dimension(280, 210));
		String title1 = "Units";
		TitledBorder border1 = BorderFactory.createTitledBorder(title1);
		border1.setTitleFont(new Font(Font.SERIF, Font.BOLD, 30));
		units.setBorder(border1);
		availableUnits = new JPanel();
		availableUnits.setBorder(new TitledBorder("Available Units:"));
		availableUnits.setPreferredSize(new Dimension(280, 200));
		respondingUnits = new JPanel();
		respondingUnits.setPreferredSize(new Dimension(280, 200));
		respondingUnits.setBorder(new TitledBorder("Responding Units:"));
		treatingUnits = new JPanel();
		treatingUnits.setPreferredSize(new Dimension(280, 200));
		treatingUnits.setBorder(new TitledBorder("Treating Units:"));
		units.add(availableUnits, BorderLayout.NORTH);
		units.add(respondingUnits, BorderLayout.CENTER);
		units.add(treatingUnits, BorderLayout.SOUTH);
		respondingUnits.setLayout(new FlowLayout());
		this.add(units, BorderLayout.EAST);
		availableUnits.setLayout(new FlowLayout());
		treatingUnits.setLayout(new FlowLayout());
	//	units.setVisible(false);
		//controller.setVisible(false);
		//x.setVisible(false);
		start.setVisible(false);
		exit.setVisible(false);
	this.setVisible(false);

	}

	public JPanel getAvailableUnits() {
		return availableUnits;
	}

	public JPanel getRespondingUnits() {
		return respondingUnits;
	}

	public JPanel getTreatingUnits() {
		return treatingUnits;
	}

	public void addBuilding(JButton building, int x, int y) {
		world.add(building, x, y);

	}

	public void addCitizen(JButton citizen, int x, int y) {
		world.add(citizen, x, y);
	}

	public void addAvailableUnits(JButton availableUnit) {
		availableUnits.add(availableUnit);
	}

	public JTextArea getInfo() {
		return info;
	}

	public JTextArea getStrukDis() {
		return strukDis;
	}

	public JTextArea getActivDis() {
		return activDis;
	}

	public void addRespondingUnits(JButton respondingUnit) {
		respondingUnits.add(respondingUnit);
	}

	public void addTreatingUnits(JButton treatingUnit) {
		treatingUnits.add(treatingUnit);
	}

	public void updateInfo(ArrayList<String> building) {

	}

	public static void main(String[] args) {
		GUIView window = new GUIView();
		window.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}