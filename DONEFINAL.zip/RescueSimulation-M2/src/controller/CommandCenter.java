package controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javafx.geometry.VerticalDirection;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

import com.sun.jndi.cosnaming.IiopUrl.Address;
import com.sun.org.apache.bcel.internal.generic.NEW;

import model.disasters.*;
import exceptions.DisasterException;
import exceptions.UnitException;
import model.events.SOSListener;
import model.infrastructure.ResidentialBuilding;
import model.people.*;
import model.units.*;
import simulation.*;
import view.*;

public class CommandCenter implements SOSListener, ActionListener {

	private ArrayList<Citizen> h = new ArrayList<Citizen>();
	private JButton start;
	private JButton exit;
	private ResidentialBuilding base;
	private ResidentialBuilding j;
	private ArrayList<Citizen> addedCitOut = new ArrayList<Citizen>();
	private ArrayList<JButton> OutCit = new ArrayList<JButton>();
	private ArrayList<Citizen> addedCitin = new ArrayList<Citizen>();
	private ArrayList<JButton> InCit = new ArrayList<JButton>();
	private JTextArea currentCycle;
	private JTextArea casualties;
	private JPanel world;
	private int cycleNumber = 1;
	private static int k = 0;
	private JPanel controller;
	private JButton respond;
	private JButton cancelRespond;
	private Simulator engine;
	private ArrayList<ResidentialBuilding> visibleBuildings;
	private ArrayList<Citizen> visibleCitizens;
	private ArrayList<Unit> emergencyUnits;
	private GUIView g;
	private ArrayList<JButton> building = new ArrayList<JButton>();
	private JButton nextCycle;
	private JButton[][] b;
	private ArrayList<String> StruckDisaster;
	private ArrayList<JButton> units = new ArrayList<JButton>();
	private static int slim = 0;
	private ArrayList<ResidentialBuilding> addedBuild = new ArrayList<ResidentialBuilding>();
	private Unit goat;
	private JPanel citizens = new JPanel();
	private ArrayList<JButton> c;
	private JFrame x = new JFrame();
	JScrollPane s = new JScrollPane(citizens);

	public CommandCenter() throws Exception {
		
		engine = new Simulator(this);
		base = new ResidentialBuilding(engine.getWorld()[0][0]);
		visibleBuildings = new ArrayList<ResidentialBuilding>();
		visibleCitizens = new ArrayList<Citizen>();
		visibleBuildings.add(base);
		emergencyUnits = engine.getEmergencyUnits();
		citizens.setLayout(new FlowLayout());
		String citizenTitle = "Citizens and Units: ";
		TitledBorder citizenBorder = BorderFactory
				.createTitledBorder(citizenTitle);
		citizens.setBorder(citizenBorder);
		this.g = new GUIView();
		setUnitButtons();
		addUnits();
		citizens.setVisible(false);

		b = new JButton[10][10];
		nextCycle = new JButton();
		nextCycle.setActionCommand("nextCycle");
		nextCycle.setText("Next Cycle");
		g.getController().add(nextCycle);
		nextCycle.addActionListener(this);
		g.setVisible(true);
		/*********/
		respond = new JButton();
		respond.setActionCommand("respond");
		respond.setText("RESPOND");
		g.getController().add(respond);
		respond.addActionListener(this);
		g.setVisible(true);

		/*********/
		cancelRespond = new JButton();
		cancelRespond.setActionCommand("Cancel Respond");
		cancelRespond.setText("CANCEL RESPOND");
		g.getController().add(cancelRespond);
		cancelRespond.addActionListener(this);
		g.setVisible(true);
		/*********/
		currentCycle = new JTextArea();
		currentCycle.setPreferredSize(new Dimension(200, 50));
		currentCycle.setEditable(false);
		currentCycle.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		String cycleTitle = "Current Cycle : ";
		TitledBorder cycleBorder = BorderFactory.createTitledBorder(cycleTitle);
		currentCycle.setBorder(cycleBorder);
		g.getController().add(currentCycle);
		/*********/
		casualties = new JTextArea();
		JScrollPane o = new JScrollPane(casualties);
		o.setPreferredSize(new Dimension(200, 50));
		o.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		casualties.setPreferredSize(new Dimension(200, 300));
		casualties.setEditable(false);
		casualties.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		String casualtiesTitle = "Casualties : ";
		TitledBorder casualtiesBorder = BorderFactory
				.createTitledBorder(casualtiesTitle);
		casualties.setBorder(casualtiesBorder);
		g.getController().add(o);
		/********/
		world = new JPanel();
		world.setLayout(new GridLayout(10, 10));
		// JButton respond=
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				JButton z = new JButton();
				z.setActionCommand("" + i + "," + j);
				b[i][j] = z;
				z.setPreferredSize(new Dimension(50, 50));
				z.setOpaque(true);
				z.addActionListener(this);
				z.setBackground(Color.white);
				world.add(z);

			}
		}
		citizens.setPreferredSize(new Dimension(200, 200));

		s.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		s.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		s.setPreferredSize(new Dimension(200, 200));
		s.setVisible(false);
		g.getP().add(citizens);

		citizens.setVisible(false);
		world.setPreferredSize(new Dimension(30, 0));
		g.add(world, BorderLayout.CENTER);
		world.setVisible(true);
		g.setVisible(false);
	
	}

	@Override
	public void receiveSOSCall(Rescuable r) {

		if (r instanceof ResidentialBuilding) {

			if (!visibleBuildings.contains(r))
				visibleBuildings.add((ResidentialBuilding) r);

		} else {

			if (!visibleCitizens.contains(r))
				visibleCitizens.add((Citizen) r);
		}

	}

	public void setUnitButtons() {
		for (int q = 0; q < emergencyUnits.size(); q++) {
			JButton x = createbtn(this.emergencyUnits.get(q));
			x.addActionListener(this);
			if (emergencyUnits.get(q) instanceof MedicalUnit)
				x.setActionCommand("unit");
			else
				x.setActionCommand("unit");

			units.add(x);
		}

	}

	public void addUnits() {

		for (int i = 0; i < this.emergencyUnits.size(); i++) {

			if (this.emergencyUnits.get(i).getState() == UnitState.IDLE) {

				g.addAvailableUnits(units.get(i));
			}
			if (this.emergencyUnits.get(i).getState() == UnitState.RESPONDING) {

				g.addRespondingUnits(units.get(i));

			}
			if (this.emergencyUnits.get(i).getState() == UnitState.TREATING) {

				g.addTreatingUnits(units.get(i));
			}

		}
	}

	// public void addB() {
	//
	// for (int i = 0; i < this.engine.buildings.size(); i++) {
	// JButton building = new JButton();
	// g.addBuilding(building, this.engine.buildings.get(i).getLocation()
	// .getX(), this.engine.buildings.get(i).getLocation().getY());
	// building.setText(this.engine.buildings.get(i).toString());
	// building.setBackground(Color.black);
	// building.setVisible(true);
	// }
	//
	// }

	public JButton createbtn(Object x) {
		JButton s = new JButton();
		s.setPreferredSize(new Dimension(50, 50));
		if (x instanceof Ambulance) {
			addimg(s, "Ambulance.jpg");
			// s.setIcon(new
			// ImageIcon("C:\\Users\\HP\\Desktop\\ambulance1.jpg"));
		}
		// if (x instanceof ResidentialBuilding) {
		//
		// //s.setIcon(new ImageIcon("C:\\Users\\HP\\Desktop\\police1.jpg"));
		// }

		if (x instanceof Evacuator) {
			addimg(s, "police1.jpg");
			// s.setIcon(new ImageIcon("C:\\Users\\HP\\Desktop\\police1.jpg"));

		}
		if (x instanceof GasControlUnit) {
			addimg(s, "gas-control1.jpg");
			// s.setIcon(new
			// ImageIcon("C:\\Users\\HP\\Desktop\\ambulance1.jpg"));
		}
		if (x instanceof DiseaseControlUnit) {
			addimg(s, "infection-control.jpg");
			// s.setIcon(new
			// ImageIcon("C:\\Users\\HP\\Desktop\\ambulance1.jpg"));
		}
		if (x instanceof FireTruck) {
			addimg(s, "fire-truck1.jpg");
			// s.setIcon(new
			// ImageIcon("C:\\Users\\HP\\Desktop\\fire-truck1.jpg"));
		}
		s.setVisible(true);
		return s;
	}

	public void addimg(JButton b, String x) {
		Image image = new ImageIcon(this.getClass().getResource(x)).getImage()
				.getScaledInstance(85, 60, Image.SCALE_DEFAULT);
		b.setIcon(new ImageIcon(image));
	}

	public void setBuilding() {
		int x;
		int y;
		for (int i = 0; i < visibleBuildings.size(); i++) {
			x = visibleBuildings.get(i).getLocation().getX();
			y = visibleBuildings.get(i).getLocation().getY();
			if (!addedBuild.contains((visibleBuildings.get(i)))) {
				addedBuild.add(visibleBuildings.get(i));

				JButton l = b[x][y];
				l.setActionCommand("building");
				building.add(l);
			}
if(visibleBuildings.get(i).getStructuralIntegrity()==0){
				
				addimg(b[x][y], "images.jpg");
			}
			if (visibleBuildings.get(i).getDisaster() != null) {
				if ((visibleBuildings.get(i).getDisaster()) instanceof Fire)
					addimg(b[x][y], "fire1.jpg");
				if ((visibleBuildings.get(i).getDisaster()) instanceof GasLeak)
					addimg(b[x][y], "gas1.jpg");
				if ((visibleBuildings.get(i).getDisaster()) instanceof Collapse)
					addimg(b[x][y], "collapse1.jpg");

			} else {
				addimg(b[x][y], "building1.jpg");
			}
if(visibleBuildings.get(i).getStructuralIntegrity()==0){
				
				addimg(b[x][y], "holmanJan09-6.gif");
			}
		}
	}

	public void setCit() {
		int x;
		int y;
		for (int i = 0; i < visibleCitizens.size(); i++) {
			x = visibleCitizens.get(i).getLocation().getX();
			y = visibleCitizens.get(i).getLocation().getY();
			for (int j = 0; j < visibleBuildings.size(); j++) {
				if (visibleCitizens.get(i).equals(
						visibleBuildings.get(j).getLocation())) {
					addedCitin.add(visibleCitizens.get(i));
					JButton q = b[x][y];
					q.addActionListener(this);
					InCit.add(q);
				}
			}
			if (!addedCitin.isEmpty()) {
				if (!addedCitOut.contains(visibleCitizens.get(i))
						&& !addedCitin.contains(visibleCitizens.get(i))) {
					addedCitOut.add(visibleCitizens.get(i));
					JButton q = b[x][y];
					q.setActionCommand("outcitizen");
					q.addActionListener(this);
					OutCit.add(q);
				}
			} else {
				if (!addedCitOut.contains(visibleCitizens.get(i))) {
					addedCitOut.add(visibleCitizens.get(i));
					JButton q = b[x][y];
					q.setActionCommand("outcitizen");
					q.addActionListener(this);
					OutCit.add(q);
				}
			}

			if ((visibleCitizens.get(i).getDisaster()) instanceof Infection)
				addimg(b[x][y], "infiction1.jpg");
			if ((visibleCitizens.get(i).getDisaster()) instanceof Injury)
				addimg(b[x][y], "bloodLoos1.jpg");
			if (visibleCitizens.get(i).getState()==CitizenState.DECEASED){
				addimg(b[x][y], "1200px-Pirate_Flag.svg.png");}
			if ((visibleCitizens.get(i).getState()==CitizenState.RESCUED))
				addimg(b[x][y], "tyrion-lannister-in-got.png");
		}
		
	}

	@SuppressWarnings("deprecation")
	public void updateCycle() {
		System.out.println(engine.checkGameOver());
		if (engine.checkGameOver()) {

			start = new JButton("Restart");
			exit = new JButton("Exit");
			JPanel q = new JPanel();
			q.setLayout(new FlowLayout());
			q.add(start);

			JPanel k = new JPanel();
			k.add(exit);
q.add(k);
			start.addActionListener(this);
			exit.addActionListener(this);
			start.setActionCommand("start");
			exit.setActionCommand("bye");
			JTextArea m = new JTextArea("Game Over !!	\n Your Score :   "
					+ engine.calculateCasualties());
			m.setFont(new Font(Font.SERIF, Font.BOLD, 50));
			x.add(m, BorderLayout.CENTER);
			x.add(q, BorderLayout.SOUTH);
			
			x.setSize(new Dimension((int) (Toolkit.getDefaultToolkit()
					.getScreenSize().getWidth()), (int) (Toolkit
					.getDefaultToolkit().getScreenSize().getHeight())));
			x.setMaximizedBounds(new Rectangle(50, 50, 800, 800));

			x.setPreferredSize(new Dimension(500, 500));
			x.setVisible(true);
			g.dispose();

		}
		allCit();
		if(!all.isEmpty())
		casualties.setText("" + engine.calculateCasualties() + " "+engine.dead(all) );
		else casualties.setText("" + engine.calculateCasualties() );
		g.getActivDis().setText(engine.activeDisaster());
		g.getStrukDis().setText(engine.StruckDisaster());
		setBuilding();
		setCit();
		for(int i=0;i<all.size();i++){
			if(all.get(i).getLocation().equals(base.getLocation())){
				if(!base.getOccupants().contains(all.get(i)))
				base.getOccupants().add(all.get(i));
			}
		}
		g.getTreatingUnits().removeAll();
		g.getTreatingUnits().revalidate();
		g.getTreatingUnits().repaint();
		g.getRespondingUnits().removeAll();
		g.getRespondingUnits().revalidate();
		g.getRespondingUnits().repaint();
		g.getAvailableUnits().removeAll();
		g.getAvailableUnits().revalidate();
		g.getAvailableUnits().repaint();
		this.addUnits();
	}

	public void actionPerformed(ActionEvent z) {

		try {
			JButton q = (JButton) z.getSource();
			if (q.getActionCommand().equals("start")) {
				CommandCenter c = new CommandCenter();
			}
			if (q.getActionCommand().equals("bye")) {
				System.exit(0);
				x.dispose();
				x.setVisible(false);
			}
			if (q.getActionCommand().equals("Cancel Respond")) {
				slim = 0;
			}
			if (slim == 3) {
				if (q.getActionCommand().equals("building")) {
					g.getInfo().setText("IncompatibleTargetException");
					slim = 1;
				}
				if ((q.getActionCommand().equals("outcitizen"))) {
					try {
						goat.respond(addedCitOut.get(OutCit.indexOf(q)));
						slim = 0;
						g.getTreatingUnits().removeAll();
						g.getTreatingUnits().revalidate();
						g.getTreatingUnits().repaint();
						g.getRespondingUnits().removeAll();
						g.getRespondingUnits().revalidate();
						g.getRespondingUnits().repaint();
						g.getAvailableUnits().removeAll();
						g.getAvailableUnits().revalidate();
						g.getAvailableUnits().repaint();
						this.addUnits();
					} catch (UnitException e) {
						g.getInfo().setText(e.getMessage());
						slim = 0;
					}
				}
				if (q.getActionCommand().equals("incitizen")) {
					try {

						System.out.println(c.indexOf(q));
						goat.respond(j.getOccupants().get(c.indexOf(q)));
						slim = 0;
						g.getTreatingUnits().removeAll();
						g.getTreatingUnits().revalidate();
						g.getTreatingUnits().repaint();
						g.getRespondingUnits().removeAll();
						g.getRespondingUnits().revalidate();
						g.getRespondingUnits().repaint();
						g.getAvailableUnits().removeAll();
						g.getAvailableUnits().revalidate();
						g.getAvailableUnits().repaint();
						this.addUnits();
						j = null;
					} catch (UnitException e) {
						g.getInfo().setText(e.getMessage());
						slim = 1;
					}
				}
			}

			if (slim == 2) {
				if (q.getActionCommand().equals("unit")
						&& q.getActionCommand().equals("unit")) {
					goat = null;
					slim = 2;
					int i = units.indexOf(q);
					goat = emergencyUnits.get(i);
				}
				if ((q.getActionCommand().equals("outcitizen"))) {
					try {
						goat.respond(addedCitOut.get(OutCit.indexOf(q)));
						slim = 0;
						g.getTreatingUnits().removeAll();
						g.getTreatingUnits().revalidate();
						g.getTreatingUnits().repaint();
						g.getRespondingUnits().removeAll();
						g.getRespondingUnits().revalidate();
						g.getRespondingUnits().repaint();
						g.getAvailableUnits().removeAll();
						g.getAvailableUnits().revalidate();
						g.getAvailableUnits().repaint();
						this.addUnits();
					} catch (UnitException e) {
						g.getInfo().setText(e.getMessage());
						slim = 1;
					}
				}
				if (q.getActionCommand().equals("building")) {
					if (!(goat instanceof MedicalUnit)) {
						try {

							goat.respond(visibleBuildings.get(building
									.indexOf(q)));
							slim = 0;
							g.getTreatingUnits().removeAll();
							g.getTreatingUnits().revalidate();
							g.getTreatingUnits().repaint();
							g.getRespondingUnits().removeAll();
							g.getRespondingUnits().revalidate();
							g.getRespondingUnits().repaint();
							g.getAvailableUnits().removeAll();
							g.getAvailableUnits().revalidate();
							g.getAvailableUnits().repaint();
							this.addUnits();

						} catch (UnitException e) {

							g.getInfo().setText(e.getMessage());
							slim = 1;
						}

					} else {
						slim = 3;
						j = visibleBuildings.get(building.indexOf(q));
						c = new ArrayList<JButton>();

						ResidentialBuilding b = visibleBuildings.get(building
								.indexOf(q));
						g.getInfo().setText(b.toString());
						c = this.getCitBut(b.getOccupants());
						this.loadcit(c);
						ArrayList<JButton> k = getUnit(b.getLocation());
						for (int i = 0; i < k.size(); i++) {
							addimg(k.get(i), "tyrion-lannister-in-got.png");
							citizens.add(k.get(i));

						}
						citizens.setVisible(true);
					}

				}
			}
			if (slim == 1) {

				if (q.getActionCommand().equals("unit")
						|| q.getActionCommand().equals("unit")) {
					goat = null;
					slim = 2;
					int i = units.indexOf(q);
					goat = emergencyUnits.get(i);
				}
			}
			if (slim == 0) {
				if (q.getActionCommand().equals("outcitizen")) {
					g.getInfo().setText(
							"" + addedCitOut.get(OutCit.indexOf(q)).toString());
				}
				if (q.getActionCommand().equals("incitizen")) {
					g.getInfo().setText(
							"" + j.getOccupants().get(c.indexOf(q)).toString());

				}
				if (q.getActionCommand().equals("building")) {

					c = new ArrayList<JButton>();
					ResidentialBuilding b = visibleBuildings.get(building
							.indexOf(q));
					j = b;
					g.getInfo().setText(b.toString());
					c = this.getCitBut(b.getOccupants());
					this.loadcit(c);
					ArrayList<JButton> k = getUnit(b.getLocation());
					for (int i = 0; i < k.size(); i++) {
						//addimg(k.get(i), "tyrion-lannister-in-got.png");

						citizens.add(k.get(i));

					}
					citizens.setVisible(true);
					// s.setVisible(true);
				}

				if (q.getActionCommand().equals("nextCycle")) {
					engine.nextCycle();
					this.updateCycle();
					int x = getCycleNumber();
					currentCycle.setText("It is cycle number " + x);
					setCycleNumber(getCycleNumber() + 1);
				}
				if (q.getActionCommand().equals("respond")) {
					slim = 1;
				}

				if (q.getActionCommand().equals("unit")
						|| q.getActionCommand().equals("unit")) {
					int i = units.indexOf(q);
					g.getInfo().setText(emergencyUnits.get(i).toString());

				}
			}
		} catch (DisasterException e) {
			g.getInfo().setText(e.getMessage());
		} catch (Exception e) {
			g.getInfo().setText(e.getMessage());
		}

	}

	public int getCycleNumber() {
		return cycleNumber;
	}

	public void setCycleNumber(int cycleNumber) {
		this.cycleNumber = cycleNumber;
	}

	public static String struck(Rescuable s) {
		String x = s.getDisaster().toString() + " "
				+ s.getLocation().toString();

		return x;

	}

	public ArrayList<JButton> getCitBut(ArrayList<Citizen> c) {
		ArrayList<JButton> q = new ArrayList<JButton>();
		for (int i = 0; i < c.size(); i++) {
			JButton x = new JButton("" + c.get(i).getName());
			x.setActionCommand("incitizen");
			x.addActionListener(this);
			q.add(x);

		}
		return q;
	}

	public void loadcit(ArrayList<JButton> c) {
		citizens.removeAll();
		citizens.repaint();
		citizens.revalidate();
		for (int i = 0; i < c.size(); i++) {
			// s.add(c.get(i));
			citizens.add(c.get(i));

		}
		g.setVisible(true);
	}

	public ArrayList<JButton> getUnit(simulation.Address address) {
		ArrayList<JButton> q = new ArrayList<JButton>();
		for (int i = 0; i < emergencyUnits.size(); i++) {
			if (emergencyUnits.get(i).getLocation().equals(address))
				q.add(units.get(i));
		}
		return q;
	}
	private  ArrayList<Citizen> all= new ArrayList<Citizen>();
public void allCit(){
	for(int i=0;i<visibleCitizens.size();i++){
		if(!all.contains(visibleCitizens.get(i)))
			all.add(visibleCitizens.get(i));
	}
		
	for(int i=0;i<visibleBuildings.size();i++){
		
		for(int y=0;y<visibleBuildings.get(i).getOccupants().size();y++ )
			if(!all.contains(visibleBuildings.get(i).getOccupants().get(y)))
			all.add(visibleBuildings.get(i).getOccupants().get(y));
	}
}
	public static void main(String[] args) throws Exception {
		CommandCenter c = new CommandCenter();

	}

}
