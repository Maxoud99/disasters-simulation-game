package exceptions;

import java.io.IOException;

public abstract class  SimulationException extends Exception{

	public SimulationException() {
		super();
	}

	public SimulationException(String arg0) {
		super(arg0);
	}
 
}
