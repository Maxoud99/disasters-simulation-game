package model.units;

import exceptions.CannotTreatException;
import exceptions.IncompatibleTargetException;
import exceptions.UnitException;
import model.disasters.Collapse;
import model.disasters.Disaster;
import model.disasters.Fire;
import model.disasters.GasLeak;
import model.disasters.Infection;
import model.disasters.Injury;
import model.events.SOSResponder;
import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;
import simulation.Simulatable;

public abstract class Unit implements Simulatable, SOSResponder {
	private String unitID;
	private UnitState state;
	private Address location;
	private Rescuable target;
	private int distanceToTarget;
	private int stepsPerCycle;
	private WorldListener worldListener;

	public Unit(String unitID, Address location, int stepsPerCycle, WorldListener worldListener) {
		this.unitID = unitID;
		this.location = location;
		this.stepsPerCycle = stepsPerCycle;
		this.state = UnitState.IDLE;
		this.worldListener = worldListener;
	}

	public void setWorldListener(WorldListener listener) {
		this.worldListener = listener;
	}

	public WorldListener getWorldListener() {
		return worldListener;
	}

	public UnitState getState() {
		return state;
	}

	public void setState(UnitState state) {
		this.state = state;
	}

	public Address getLocation() {
		return location;
	}

	public void setLocation(Address location) {
		this.location = location;
	}

	public String getUnitID() {
		return unitID;
	}

	public Rescuable getTarget() {
		return target;
	}

	public int getStepsPerCycle() {
		return stepsPerCycle;
	}

	public void setDistanceToTarget(int distanceToTarget) {
		this.distanceToTarget = distanceToTarget;
	}

	public boolean compatible(Rescuable r) {
		Unit u = this;
		if (r instanceof ResidentialBuilding) {
			Disaster d = r.getDisaster();
			if (u instanceof DiseaseControlUnit)
				return false;
			if (u instanceof Ambulance)
				return false;
		}
		if (r instanceof Citizen) {
			Disaster d = r.getDisaster();
			if (u instanceof FireTruck)
				return false;
			if (u instanceof GasControlUnit)
				return false;
			if (u instanceof Evacuator)
				return false;

		}
		return true;
	}

	@Override
	public void respond(Rescuable r) throws UnitException {
		if (!this.compatible(r))
			throw new IncompatibleTargetException(this, r, "IncompatibleTargetException");
		if (!canTreat(r))
			throw new CannotTreatException(this, r, "CannotTreatException");
		if (!helper(r))
			throw new CannotTreatException(this, r, "CannotTreatException");
	
		if (target != null && state == UnitState.TREATING)
			reactivateDisaster();
		finishRespond(r);

	}

	public void reactivateDisaster() {
		Disaster curr = target.getDisaster();
		curr.setActive(true);
	}

	public void finishRespond(Rescuable r) {
		target = r;
		state = UnitState.RESPONDING;
		Address t = r.getLocation();
		distanceToTarget = Math.abs(t.getX() - location.getX()) + Math.abs(t.getY() - location.getY());

	}

	public abstract void treat();

	public void cycleStep() {
		if (state == UnitState.IDLE)
			return;
		if (distanceToTarget > 0) {
			distanceToTarget = distanceToTarget - stepsPerCycle;
			if (distanceToTarget <= 0) {
				distanceToTarget = 0;
				Address t = target.getLocation();
				worldListener.assignAddress(this, t.getX(), t.getY());
			}
		} else {
			state = UnitState.TREATING;
			treat();
		}
	}

	public void jobsDone() {
		target = null;
		state = UnitState.IDLE;

	}

	public boolean helper(Rescuable r) {
		if (r instanceof ResidentialBuilding) {
			if (this instanceof Evacuator) {
				if (!(r.getDisaster() instanceof Collapse)) {
					return false;
				}
			}
			if (this instanceof FireTruck) {
				if (!(r.getDisaster() instanceof Fire)) {
					return false;
				}
			}
			if (this instanceof GasControlUnit) {
				if (!(r.getDisaster() instanceof GasLeak)) {
					return false;
				}
			}
		}
		if (r instanceof Citizen) {
			if (this instanceof Ambulance) {
				if (!(r.getDisaster() instanceof Injury)) {
					return false;
				}
			}
			if (this instanceof DiseaseControlUnit) {
				if (!(r.getDisaster() instanceof Infection)) {
					return false;
				}
			}
		}
		return true;
	}

	public boolean canTreat(Rescuable r) {
		if (r instanceof Citizen) {
			Citizen c = (Citizen) r;
			if (c.getState() == CitizenState.IN_TROUBLE) {
				return true;
			}
		}
		if (r instanceof ResidentialBuilding) {
			ResidentialBuilding R = (ResidentialBuilding) r;

			if (((ResidentialBuilding) r).getStructuralIntegrity() != 0 && r.getDisaster() != null
					&& r.getDisaster().isActive())
				return true;

		}
		return false;
	}
	
}
