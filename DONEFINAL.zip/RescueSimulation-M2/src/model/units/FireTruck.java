package model.units;

import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import simulation.Address;

public class FireTruck extends FireUnit {

	public FireTruck(String unitID, Address location, int stepsPerCycle,
			WorldListener worldListener) {
		super(unitID, location, stepsPerCycle, worldListener);
	}

	@Override
	public void treat() {
		getTarget().getDisaster().setActive(false);

		ResidentialBuilding target = (ResidentialBuilding) getTarget();
		if (target.getStructuralIntegrity() == 0) {
			jobsDone();
			return;
		} else if (target.getFireDamage() > 0)

			target.setFireDamage(target.getFireDamage() - 10);

		if (target.getFireDamage() == 0)

			jobsDone();

	}

	public String toString() {
		if(getTarget()!=null)
		return "Unit ID : " + getUnitID() + " \n" + "Unit Type : Fire Truck"
				+ "\n" + "Location : " + getLocation().toString() + "\n"
				+ "Steps per Cycle : " + getStepsPerCycle() + "\n"
				+ "Target : Citizen" + getTarget().getLocation().toString()
				+ "\n" + "Unit State" + getState() + "\n";
		else
			return "Unit ID : " + getUnitID() + " \n" + "Unit Type : Fire Truck"
			+ "\n" + "Location : " + getLocation().toString() + "\n"
			+ "Steps per Cycle : " + getStepsPerCycle() + "\n"
			+ "Target : No Target"
			+ "\n" + "Unit State" + getState() + "\n";
	}
}
