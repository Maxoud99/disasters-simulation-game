package model.units;

import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import simulation.Address;

public class GasControlUnit extends FireUnit {

	public GasControlUnit(String unitID, Address location, int stepsPerCycle,
			WorldListener worldListener) {
		super(unitID, location, stepsPerCycle, worldListener);
	}

	public void treat() {
		getTarget().getDisaster().setActive(false);

		ResidentialBuilding target = (ResidentialBuilding) getTarget();
		if (target.getStructuralIntegrity() == 0) {
			jobsDone();
			return;
		} else if (target.getGasLevel() > 0) 
			target.setGasLevel(target.getGasLevel() - 10);

		if (target.getGasLevel() == 0)
			jobsDone();

	}
	public String toString() {
		if(getTarget()!=null)
		return "Unit ID : " + getUnitID() + " \n" + "Unit Type : Gas Cotrol Unit"
				+ "\n" + "Location : " + getLocation().toString() + "\n"
				+ "Steps per Cycle : " + getStepsPerCycle() + "\n"
				+ "Target : Citizen" + getTarget().getLocation().toString()
				+ "\n" + "Unit State" + getState() + "\n";
		else
			return "Unit ID : " + getUnitID() + " \n" + "Unit Type : Gas Cotrol Unit"
			+ "\n" + "Location : " + getLocation().toString() + "\n"
			+ "Steps per Cycle : " + getStepsPerCycle() + "\n"
			+ "Target :No target" 
			+ "\n" + "Unit State" + getState() + "\n";
	}
}
