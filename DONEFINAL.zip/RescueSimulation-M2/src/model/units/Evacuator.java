package model.units;

import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import simulation.Address;

public class Evacuator extends PoliceUnit {

	public Evacuator(String unitID, Address location, int stepsPerCycle,
			WorldListener worldListener, int maxCapacity) {
		super(unitID, location, stepsPerCycle, worldListener, maxCapacity);

	}

	@Override
	public void treat() {
		ResidentialBuilding target = (ResidentialBuilding) getTarget();
		if (target.getStructuralIntegrity() == 0
				|| target.getOccupants().size() == 0) {
			jobsDone();
			return;
		}

		for (int i = 0; getPassengers().size() != getMaxCapacity()
				&& i < target.getOccupants().size(); i++) {
			getPassengers().add(target.getOccupants().remove(i));
			i--;
		}

		setDistanceToBase(target.getLocation().getX()
				+ target.getLocation().getY());

	}

	public String toString() {

		String x = "";
		for (int i = 0; i < getPassengers().size(); i++) {
			x += getPassengers().get(i).toString() + "\n";
		}
		if (getTarget() != null)
			return "Unit ID : " + getUnitID() + " \n"
					+ " Unit Type : Evacuator" + "\n" + "Location : "
					+ getLocation().toString() + "\n" + "Steps per Cycle : "
					+ getStepsPerCycle() + "\n" + "Target : Citizen"
					+ getTarget().getLocation().toString() + "\n"
					+ "Unit State" + getState() + "\n"
					+ "Number Of Passenger : " + getPassengers().size() + "\n"
					+ "Passengers info : " + x;
		else
			return "Unit ID : " + getUnitID() + " \n"
					+ "Unit Type : Evacuator" + "\n" + "Location : "
					+ getLocation().toString() + "\n" + "Steps per Cycle : "
					+ getStepsPerCycle() + "\n" + "Target : No Target" + "\n"
					+ "Unit State" + getState() + "\n"
					+ "Number Of Passenger : " + getPassengers().size() + "\n"
					+ "Passengers info : " + x;
	}
}
