package model.units;

import exceptions.CannotTreatException;
import exceptions.IncompatibleTargetException;
import exceptions.UnitException;
import model.disasters.Infection;
import model.disasters.Injury;
import model.events.WorldListener;
import model.people.Citizen;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;

public class Ambulance extends MedicalUnit {

	public Ambulance(String unitID, Address location, int stepsPerCycle,
			WorldListener worldListener) {
		super(unitID, location, stepsPerCycle, worldListener);
	}

	@Override
	public void treat() {
		getTarget().getDisaster().setActive(false);

		Citizen target = (Citizen) getTarget();
		if (target.getHp() == 0) {
			jobsDone();
			return;
		} else if (target.getBloodLoss() > 0) {
			target.setBloodLoss(target.getBloodLoss() - getTreatmentAmount());
			if (target.getBloodLoss() == 0)
				target.setState(CitizenState.RESCUED);
		}

		else if (target.getBloodLoss() == 0)

			heal();

	}

	public void respond(Rescuable r) throws UnitException {
		if (!canTreat(r))
			throw new CannotTreatException(this, r, "CannotTreatException");
		if (!helper(r))
			throw new CannotTreatException(this, r, "CannotTreatException");
		if (!this.compatible(r))
			throw new IncompatibleTargetException(this, r,
					"IncompatibleTargetException");
		if ((r instanceof Citizen)) {
			if (getTarget() != null
					&& ((Citizen) getTarget()).getBloodLoss() > 0
					&& getState() == UnitState.TREATING)
				reactivateDisaster();
			finishRespond(r);
		}

	}

	public String toString() {
		if(this.getTarget()!=null)
			
		return "Unit ID : " + getUnitID() + " \n" + " Unit Type : Ambulance"
				+ "\n" + "Location : " + getLocation().toString() + "\n"
				+ "Steps per Cycle : " + getStepsPerCycle() + "\n"
				+ "Target : Citizen" + getTarget().getLocation().toString()
				+ "\n" + "Unit State" + getState() + "\n";
		else
			return "Unit ID : " + getUnitID() + " \n" + "Unit Type : Ambulance"
			+ "\n" + "Location : " + getLocation().toString() + "\n"
			+ "Steps per Cycle : " + getStepsPerCycle() + "\n"
			+ "Target : Citizen: No Target" 
			+ "\n" + "Unit State" + getState() + "\n";
	}

}
